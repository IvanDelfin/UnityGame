CREATE PROCEDURE SPTestPlayers AS
INSERT INTO [dbo].[Usuario] values ('player1','player1','1','1','False')
INSERT INTO [dbo].[Usuario] values ('player2','player2','2','2','False')
INSERT INTO [dbo].[Usuario] values ('player3','player3','3','3','True')
INSERT INTO [dbo].[Usuario] values ('player1','player1','1','1','False')

INSERT INTO [dbo].[Player] values (0,'player1',3000,0,0,