CREATE TABLE Player(
    playerID INT IDENTITY (1,1) NOT NULL PRIMARY KEY CLUSTERED,
    playerExperience INT,
    playerName VARCHAR(100),
    scoreMoney INT,
    scoreIron FLOAT,
    scoreUnpackageSteel FLOAT,
    scoreSteel FLOAT,
    difficulty INT,
    tutorial BIT
);

CREATE TABLE Setting(
    playerID INT NOT NULL,
    constraint PK_Setting primary key (playerID),
    constraint FK_playerID foreign key (playerID) references Player(playerID),
    volumeMusic FLOAT,
    cameraSensibility FLOAT,
    cameraSpeed FLOAT
);


CREATE TABLE Statistic(
    playerID INT CONSTRAINT FK_Statistic_playerID FOREIGN KEY(playerID) references Player(playerID),
    statisticID int identity (1,1) NOT NULL PRIMARY KEY CLUSTERED,
    timeDate DATETIME NOT NULL,
    constructionNumber INT,
    totalMoney FLOAT,
    totalSteel FLOAT,
    totalContract INT,
    playerExperience INT,
    totalIron FLOAT,
    totalunpackageSteel FLOAT,
    ironToSteelTransform FLOAT
);

CREATE TABLE Contract(
    playerID INT constraint FK_Contract_playerID foreign key (playerID) references Player(playerID),
    contractID INT IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
    contractGameID INT,
    title VARCHAR(100),
    description VARCHAR(500),
    steelRequirement INT,
    moneyReward INT,
    timeRemaining FLOAT,
    penalization FLOAT,
    success INT,
    isActive INT
);

CREATE TABLE Trade(
    playerID INT constraint FK_Trade_PlayerID foreign key (playerID) references player(playerID),
    tradeID INT IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
    playerToTradeID INT,
    steelAmount INT,
    steelCost INT,
    acceptTradeP1 INT,
    acceptTradeP2 INT,
    isComplete1 INT,
    isComplete2 INT
);

CREATE TABLE Friend(
    playerID INT constraint FK_Friend_PlayerID foreign key (playerID) references Player(playerID),
    relationID INT IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
    friendID INT,
    Status1 INT,
    Status2 INT,
    UpdateData INT
);

CREATE TABLE Building(
    playerID INT constraint FK_Building_PlayerID foreign key (playerID) references Player(playerID),
    buildingID INT IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
    buildingGameID INT,
    buildingType Varchar(50),
    posX FLOAT,
    posZ FLOAT,
    rotation FLOAT,
    attributeBuildingData VARCHAR(100)
);

CREATE TABLE Usuario(
    IDUsuario INT IDENTITY (1,1) NOT NULL PRIMARY KEY CLUSTERED,
    Nombre VARCHAR(250),
    Apellido VARCHAR(250),
    Email VARCHAR(250),
    Password VARCHAR(250),
    EsAdministrador BIT
);

CREATE TABLE Feedback(
    feedbackID int identity (1,1) NOT NULL PRIMARY KEY CLUSTERED,
    feedbackName VARCHAR(250)
);

CREATE TABLE Player_Feedback(
    playerID INT constraint FK_Player_FeedbackID foreign key (playerID) references Player(playerID),
	feedbackID INT constraint FK_Feedback_PlayerID foreign key (feedbackID) references Feedback(feedbackID),
    activated BIT
);


CREATE TABLE Quiz(
    QuizID INT IDENTITY (1,1) NOT NULL PRIMARY KEY CLUSTERED,
    questionImage VARCHAR(250),
    answer VARCHAR(250)
);

INSERT INTO [dbo].[Feedback] values ('furnaceFeedback');
INSERT INTO [dbo].[Feedback] values ('energyFeedback');
INSERT INTO [dbo].[Feedback] values ('friendFeedback');

insert into [dbo].[Quiz] values('Drywall','Drywall');
insert into [dbo].[Quiz] values('PerfilC','PerfilC');
insert into [dbo].[Quiz] values('PerfilU','PerfilU');

CREATE PROCEDURE SPGetBuilding @inputPlayerID INT AS
SELECT * FROM Building
WHERE playerID = @inputPlayerID;
GO
CREATE PROCEDURE SPUpdateBuilding @playerID INT, @buildingGameID INT, @buildingType VARCHAR(50), @posX FLOAT, @posZ FLOAT, @rotation FLOAT, @attributeBuildingData VARCHAR(100) AS
declare @temp_building TABLE(
    playerID INT,
    buildingGameID INT,
    buildingType VARCHAR(50),
    posX FLOAT,
    posZ FLOAT,
    rotation FLOAT,
    attributeBuildingData VARCHAR(100)    
);

INSERT INTO @temp_building VALUES(
    @playerID,
    @buildingGameID,
    @buildingType,
    @posX,
    @posZ,
    @rotation,
    @attributeBuildingData 
)

MERGE Building as Target
USING(SELECT playerID, buildingGameID, buildingType, posX, posZ, rotation, attributeBuildingData FROM @temp_building) AS Source
ON(Target.playerID = Source.playerID AND Target.buildingGameID = Source.buildingGameID)
WHEN MATCHED THEN
    UPDATE SET 
        Target.buildingType = Source.buildingType,
        Target.posX = Source.posX,
        Target.posZ = Source.posZ,
        Target.rotation = Source.rotation,
        Target.attributeBuildingData = Source.attributeBuildingData
WHEN NOT MATCHED BY TARGET THEN
    INSERT(playerID, buildingGameID, buildingType, posX, posZ, rotation, attributeBuildingData)
    VALUES(Source.playerID, Source.buildingGameID, Source.buildingType, Source.posX, Source.posZ, Source.rotation, Source.attributeBuildingData);
GO
CREATE PROCEDURE SPDeleteBuilding @playerID INT, @buildingGameID INT AS
DELETE FROM Building
WHERE playerID = @playerID AND buildingGameID = @buildingGameID;
GO
CREATE PROCEDURE SPUpdateContract @playerID INT, @contractGameID INT, @title VARCHAR(100), @description VARCHAR(500), @steelRequirement INT, @moneyReward INT, @timeRemaining FLOAT, @penalization FLOAT, @success INT, @isActive INT AS
declare @temp_contract TABLE(
    playerID INT,
    contractGameID INT,
    title VARCHAR(100),
    description VARCHAR(500),
    steelRequirement INT,
    moneyReward INT,
    timeRemaining FLOAT,
    penalization FLOAT,
    success INT, 
    isActive INT
);

INSERT INTO @temp_contract VALUES(
    @playerID,
    @contractGameID,
    @title,
    @description,
    @steelRequirement,
    @moneyReward,
    @timeRemaining,
    @penalization,
    @success,
    @isActive
)

MERGE Contract AS TARGET
USING (SELECT playerID, contractGameID, title, description, steelRequirement, moneyReward, timeRemaining, penalization, success, isActive FROM @temp_contract) AS Source
ON(Target.playerID = Source.playerID AND Target.contractGameID = Source.contractGameID)
WHEN MATCHED THEN
    UPDATE SET
        Target.timeRemaining = Source.timeRemaining,
        Target.success = Source.success,
        TARGET.isActive = Source.isActive
WHEN NOT MATCHED BY TARGET THEN
    INSERT(playerID, contractGameID, title, description, steelRequirement, moneyReward, timeRemaining, penalization, success, isActive)
    VALUES(Source.playerID, Source.contractGameID, Source.title, Source.description, Source.steelRequirement, Source.moneyReward, Source.timeRemaining, Source.penalization, Source.success, Source.isActive); 
GO
CREATE PROCEDURE SPAddContract @playerID INT, @contractGameID INT, @title VARCHAR(100), @descripcion VARCHAR(500), @steelRequirement INT, @moneyReward INT, @timeRemaining FLOAT, @penalization FLOAT, @success INT, @isActive INT AS
INSERT INTO Contract VALUES(
    @playerID,
    @contractGameID,
    @title,
    @descripcion,
    @steelRequirement,
    @moneyReward,
    @timeRemaining,
    @penalization,
    @success,
    @isActive
);
GO
CREATE PROCEDURE SPGetLastContract @playerID INT AS
SELECT *
FROM Contract
WHERE playerID = @playerID  AND contractID = (SELECT MAX(contractGameID) FROM Contract);
GO
CREATE PROCEDURE SPAddFeedback @playerID INT, @furnaceFeedback BIT, @energyFeedback BIT, @friendFeedback BIT AS
INSERT INTO [dbo].[Player_Feedback] values (@playerID, 1, @furnaceFeedback);
INSERT INTO [dbo].[Player_Feedback] values (@playerID, 2, @energyFeedback);
INSERT INTO [dbo].[Player_Feedback] values (@playerID, 3, @friendFeedback);
GO
CREATE PROCEDURE SPUpdateFeedback @playerID INT, @furnaceFeedback BIT, @energyFeedback BIT, @friendFeedback BIT AS
UPDATE [dbo].[Player_Feedback] SET activated = @furnaceFeedback WHERE playerID = @playerID AND feedbackID = 1;
UPDATE [dbo].[Player_Feedback] SET activated = @energyFeedback WHERE playerID = @playerID AND feedbackID = 2;
UPDATE [dbo].[Player_Feedback] SET activated = @friendFeedback WHERE playerID = @playerID AND feedbackID = 3;
GO
CREATE PROCEDURE SPCheckFriendUpdate @playerID INT AS 
SELECT UpdateData, friendID
FROM Friend
WHERE playerID = @playerID
UPDATE Friend
SET UpdateData = 0
WHERE playerID = 1;
GO
CREATE PROCEDURE SPGetFriendData @playerID INT AS
SELECT Friend.playerID, Player.playerName 
FROM Friend
INNER JOIN Player ON Player.playerID = Friend.playerID
WHERE friendID = @playerID AND Status1 = 1 AND Status2 = 1;
GO
CREATE PROCEDURE SPCheckFriendRequest @playerID INT AS
SELECT Friend.playerID, Player.playerName
FROM Friend
INNER JOIN Player ON Player.playerID = Friend.playerID
WHERE friendID = @playerID AND Status2 = 0;
GO
CREATE PROCEDURE SPFindStatistic @playerID INT AS 
SELECT Statistic.*, Player.playerName
FROM Statistic
INNER JOIN Player ON Player.playerID = Statistic.playerID 
WHERE Statistic.playerID = @playerID;
GO
CREATE PROCEDURE SPAcceptFriendRequest @playerID INT, @friendID INT AS
UPDATE Friend
SET Status2 = 1,
    UpdateData = 1
WHERE playerID = @friendID AND friendID = @playerID
INSERT INTO Friend VALUES(
    @playerID,
    @friendID,
    1,
    1,
    1
);
GO
CREATE PROCEDURE SPFinishRelationship @playerID INT, @friendID INT AS
DELETE Friend
WHERE playerID = @playerID AND friendID = @friendID
DELETE Friend
WHERE playerID = @friendID AND friendID = @playerID;
GO
CREATE PROCEDURE SPFindFriendName @playerID INT AS
SELECT playerName, playerID
FROM player
WHERE playerID = @playerID;
GO
CREATE PROCEDURE SPSendFriendRequest @playerID INT, @friendID INT AS
DECLARE @temp_friend TABLE(
    playerID INT,
    friendID INT
);
INSERT INTO @temp_friend VALUES(
    @playerID,
    @friendID
)
MERGE Friend as Target
USING(SELECT playerID, friendID FROM @temp_friend) AS Source
ON(Target.playerID = Source.playerID AND Target.friendID = Source.friendID)
WHEN NOT MATCHED BY TARGET THEN
    INSERT(playerID, friendID, Status1, Status2, UpdateData)
    VALUES(Source.playerID, Source.friendID, 1, 0, 1);
GO
CREATE PROCEDURE SPUpdatePlayer @playerID INT, @playerExperience INT, @playerName VARCHAR(100), @scoreMoney INT, @scoreIron FLOAT, @scoreUnpackageSteel FLOAT, @scoreSteel FLOAT, @difficulty INT, @tutorial BIT AS
declare @temp_player TABLE(
    playerID INT,
    playerExperience INT,
    playerName VARCHAR(100),
    scoreMoney INT,
    scoreIron FLOAT,
    scoreUnpackageSteel FLOAT,
    scoreSteel FLOAT,
    difficulty INT,
    tutorial BIT
);
INSERT INTO @temp_player VALUES(
    @playerID,
    @playerExperience,
    @playerName,
    @scoreMoney,
    @scoreIron,
    @scoreUnpackageSteel,
    @scoreSteel,
    @difficulty,
    @tutorial
)
MERGE Player as Target
USING(SELECT playerID, playerExperience, playerName, scoreMoney, scoreIron, scoreUnpackageSteel, scoreSteel, difficulty, tutorial FROM @temp_player) AS Source
ON(Target.playerID = Source.playerID)
WHEN MATCHED THEN
    UPDATE SET 
        Target.playerExperience = Source.playerExperience,
        Target.playerName = Source.playerName,
        Target.scoreMoney = Source.scoreMoney,
        Target.scoreIron = Source.scoreIron,
        Target.scoreUnpackageSteel = Source.scoreUnpackageSteel,
        Target.scoreSteel = Source.scoreSteel,
        Target.difficulty = Source.difficulty,
        Target.tutorial = Source.tutorial
WHEN NOT MATCHED BY TARGET THEN
    INSERT(playerExperience, playerName, scoreMoney, scoreIron, scoreUnpackageSteel, scoreSteel, difficulty,tutorial)
    VALUES(Source.playerExperience, Source.playerName, Source.scoreMoney, Source.scoreIron, Source.scoreUnpackageSteel, Source.scoreSteel, Source.difficulty, Source.tutorial);
GO
CREATE PROCEDURE SPGetPlayer @playerID INT AS
SELECT * FROM Player
WHERE playerID = @playerID;
GO
CREATE PROCEDURE SPInsertSetting @playerID INT, @volumeMusic FLOAT, @cameraSensibility FLOAT, @cameraSpeed FLOAT AS
INSERT INTO Setting VALUES(
    @playerID,
    @volumeMusic,
    @cameraSensibility,
    @cameraSpeed
);
GO
CREATE PROCEDURE SPUpdateSetting @playerID INT, @volumeMusic FLOAT, @cameraSensibility FLOAT, @cameraSpeed FLOAT AS
UPDATE Setting
SET volumeMusic = @volumeMusic,
    cameraSensibility = @cameraSensibility,
    cameraSpeed = @cameraSpeed
WHERE playerID = @playerID;
GO
CREATE PROCEDURE SPGetSetting @playerID INT AS
SELECT * FROM Setting
WHERE playerID = @playerID;
GO
CREATE PROCEDURE SPInsertStatistic @playerID INT, @ironToSteelTransform INT AS 
DECLARE @NewDate AS DATETIME = GETDATE()

DECLARE @totalContract AS INT
SET @totalContract = (SELECT COUNT(success) FROM Contract WHERE playerID = @playerID AND success = 1)

DECLARE @contructionNumber AS INT
SET @contructionNumber  = (SELECT COUNT(success) FROM Contract WHERE playerID = @playerID AND success = 1)

DECLARE @totalMoney AS INT 
SET @totalMoney =  (SELECT scoreMoney FROM Player WHERE playerID = @playerID)

DECLARE @totalSteel AS INT 
SET @totalSteel = (SELECT scoreSteel FROM Player WHERE playerID = @playerID)

DECLARE @playerExperience AS INT 
SET @playerExperience = (SELECT playerExperience FROM Player WHERE playerID = @playerID)

DECLARE @totalIron AS INT  
SET @totalIron = (SELECT scoreIron FROM Player WHERE playerID = @playerID)

DECLARE @totalUnpackageSteel AS INT
SET @totalUnpackageSteel = (SELECT scoreUnpackageSteel FROM Player WHERE playerID = @playerID)

INSERT INTO Statistic VALUES(
    @playerID,
    @NewDate,
    @contructionNumber,
    @totalMoney,
    @totalSteel,
    @totalContract,
    @playerExperience,
    @totalIron,
    @totalUnpackageSteel,
    @ironToSteelTransform
);
GO
CREATE PROCEDURE SPGetTrade @playerID INT AS
SELECT * FROM Trade
WHERE (playerID = @playerID OR playerToTradeID = @playerID) AND (isComplete2 = 0 OR isComplete1 = 0);
GO
CREATE PROCEDURE SPCreateTrade @playerID INT, @playerToTradeID INT, @steelAmount INT, @steelCost INT AS
DECLARE @temp_trade TABLE(
    playerID INT,
    playerToTradeID INT,
    steelAmount INT,
    steelCost INT
)

INSERT INTO @temp_trade VALUES(
    @playerID,
    @playerToTradeID,
    @steelAmount,
    @steelCost
)
MERGE Trade AS Target
USING(SELECT * FROM @temp_trade) AS Source
ON((Target.playerID = Source.playerID AND Target.playerToTradeID = Source.playerToTradeID AND isComplete1 = 0) OR (Target.playerID = Source.playerToTradeID AND Target.playerToTradeID = Source.playerID AND isComplete1 = 0))
WHEN NOT MATCHED BY TARGET THEN
    INSERT(playerID, playerToTradeID, steelAmount, steelCost, acceptTradeP1, acceptTradeP2, isComplete1, isComplete2)
    VALUES(Source.playerID, Source.playerToTradeID, Source.steelAmount, Source.steelCost, 1, 0, 0, 0);
GO
CREATE PROCEDURE SPModifyTrade @playerID INT, @playerToTradeID INT, @newSteelAmount INT, @newSteelCost INT, @acceptTradeP1 INT, @acceptTradeP2 INT AS
UPDATE Trade
SET steelAmount = @newSteelAmount, steelCost = @newSteelCost, acceptTradeP1 = @acceptTradeP1, acceptTradeP2 = @acceptTradeP2
WHERE (playerID = @playerID AND playerToTradeID = @playerToTradeID AND isComplete1 = 0) OR (playerID = @playerToTradeID AND playerToTradeID = @playerID AND isComplete2 = 0);
GO
CREATE PROCEDURE SPAcceptTrade @playerID INT, @playerToTradeID INT AS
UPDATE Trade
    SET acceptTradeP1 = (CASE WHEN playerID = @playerID THEN '1' ELSE acceptTradeP1 END),
        acceptTradeP2 = (CASE WHEN playerToTradeID = @playerID THEN '1' ELSE acceptTradeP2 END),
        isComplete1 = (CASE WHEN playerID = @playerID THEN '1' ELSE isComplete1 END),
        isComplete2  = (CASE WHEN playerToTradeID = @playerID THEN '1' ELSE isComplete2 END)
WHERE (playerID = @playerID AND playerToTradeID = @playerToTradeID) OR (playerID = @playerToTradeID AND playerToTradeID = @playerID);
GO
CREATE PROCEDURE SPDeleteTrade @playerID INT, @playerToTradeID INT AS
DELETE Trade
WHERE ((playerID = @playerID AND playerToTradeID = @playerToTradeID) OR (playerID = @playerToTradeID AND playerToTradeID = @playerID)) AND (isComplete1 = 0 AND isComplete2 = 0);
GO
CREATE PROCEDURE SPRESET AS
drop table [dbo].[Usuario];
drop table [dbo].[Building];
drop table [dbo].[Contract];
drop table [dbo].[Setting];
drop table [dbo].[Friend];
drop table [dbo].[Statistic];
drop table [dbo].[Trade];
drop table [dbo].[Player_Feedback];
drop table [dbo].[Feedback];
drop table [dbo].[Player];

CREATE TABLE Player(
    playerID INT IDENTITY (1,1) NOT NULL PRIMARY KEY CLUSTERED,
    playerExperience INT,
    playerName VARCHAR(100),
    scoreMoney INT,
    scoreIron FLOAT,
    scoreUnpackageSteel FLOAT,
    scoreSteel FLOAT,
    difficulty INT,
    tutorial BIT
);

CREATE TABLE Setting(
    playerID INT NOT NULL,
    constraint PK_Setting primary key (playerID),
    constraint FK_playerID foreign key (playerID) references Player(playerID),
    volumeMusic FLOAT,
    cameraSensibility FLOAT,
    cameraSpeed FLOAT
);


CREATE TABLE Statistic(
    playerID INT CONSTRAINT FK_Statistic_playerID FOREIGN KEY(playerID) references Player(playerID),
    statisticID int identity (1,1) NOT NULL PRIMARY KEY CLUSTERED,
    timeDate DATETIME NOT NULL,
    constructionNumber INT,
    totalMoney FLOAT,
    totalSteel FLOAT,
    totalContract INT,
    playerExperience INT,
    totalIron FLOAT,
    totalunpackageSteel FLOAT,
    ironToSteelTransform FLOAT
);

CREATE TABLE Contract(
    playerID INT constraint FK_Contract_playerID foreign key (playerID) references Player(playerID),
    contractID INT IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
    contractGameID INT,
    title VARCHAR(100),
    description VARCHAR(500),
    steelRequirement INT,
    moneyReward INT,
    timeRemaining FLOAT,
    penalization FLOAT,
    success INT,
    isActive INT
);

CREATE TABLE Trade(
    playerID INT constraint FK_Trade_PlayerID foreign key (playerID) references player(playerID),
    tradeID INT IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
    playerToTradeID INT,
    steelAmount INT,
    steelCost INT,
    acceptTradeP1 INT,
    acceptTradeP2 INT,
    isComplete1 INT,
    isComplete2 INT
);

CREATE TABLE Friend(
    playerID INT constraint FK_Friend_PlayerID foreign key (playerID) references Player(playerID),
    relationID INT IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
    friendID INT,
    Status1 INT,
    Status2 INT,
    UpdateData INT
);

CREATE TABLE Building(
    playerID INT constraint FK_Building_PlayerID foreign key (playerID) references Player(playerID),
    buildingID INT IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
    buildingGameID INT,
    buildingType Varchar(50),
    posX FLOAT,
    posZ FLOAT,
    rotation FLOAT,
    attributeBuildingData VARCHAR(100)
);

CREATE TABLE Usuario(
    IDUsuario INT IDENTITY (1,1) NOT NULL PRIMARY KEY CLUSTERED,
    Nombre VARCHAR(250),
    Apellido VARCHAR(250),
    Email VARCHAR(250),
    Password VARCHAR(250),
    EsAdministrador BIT
);

CREATE TABLE Feedback(
    feedbackID int identity (1,1) NOT NULL PRIMARY KEY CLUSTERED,
    feedbackName VARCHAR(250)
);

CREATE TABLE Player_Feedback(
    playerID INT constraint FK_Player_FeedbackID foreign key (playerID) references Player(playerID),
	feedbackID INT constraint FK_Feedback_PlayerID foreign key (feedbackID) references Feedback(feedbackID),
    activated BIT
);

INSERT INTO [dbo].[Feedback] values ('furnaceFeedback');
INSERT INTO [dbo].[Feedback] values ('energyFeedback');
INSERT INTO [dbo].[Feedback] values ('friendFeedback');