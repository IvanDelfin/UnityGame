-- ********************* wut estas 2 lineas x2
-- DELETE Friend
-- DBCC CHECKIDENT('Usuario', RESEED, 0)


-- INSERT INTO Friend VALUES(
--     2,
--     1,
--     1,
--     0,
--     0
-- )

-- INSERT INTO Friend VALUES(
--     9,
--     1,
--     1,
--     0,
--     0
-- )

-- INSERT INTO Friend VALUES(
--     1,
--     3,
--     1,
--     1,
--     1
-- )

-- INSERT INTO Friend VALUES(
--     3,
--     1,
--     1,
--     1,
--     0
-- )



-- *****Esta estaba comentada y las demas no, hay que ver los id a ver si no explota
-- INSERT INTO Friend VALUES(
--     1,
--     8,
--     1,
--     0,
--     0
-- )