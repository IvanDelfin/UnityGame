CREATE PROCEDURE SPRESET AS
drop table [dbo].[Usuario];
drop table [dbo].[Building];
drop table [dbo].[Contract];
drop table [dbo].[Setting];
drop table [dbo].[Friend];
drop table [dbo].[Statistic];
drop table [dbo].[Trade];
drop table [dbo].[Player_Feedback];
drop table [dbo].[Feedback];
drop table [dbo].[Player];

CREATE TABLE Player(
    playerID INT IDENTITY (1,1) NOT NULL PRIMARY KEY CLUSTERED,
    playerExperience INT,
    playerName VARCHAR(100),
    scoreMoney INT,
    scoreIron FLOAT,
    scoreUnpackageSteel FLOAT,
    scoreSteel FLOAT,
    difficulty INT,
    tutorial BIT
);

CREATE TABLE Setting(
    playerID INT NOT NULL,
    constraint PK_Setting primary key (playerID),
    constraint FK_playerID foreign key (playerID) references Player(playerID),
    volumeMusic FLOAT,
    cameraSensibility FLOAT,
    cameraSpeed FLOAT
);


CREATE TABLE Statistic(
    playerID INT CONSTRAINT FK_Statistic_playerID FOREIGN KEY(playerID) references Player(playerID),
    statisticID int identity (1,1) NOT NULL PRIMARY KEY CLUSTERED,
    timeDate DATETIME NOT NULL,
    constructionNumber INT,
    totalMoney FLOAT,
    totalSteel FLOAT,
    totalContract INT,
    playerExperience INT,
    totalIron FLOAT,
    totalunpackageSteel FLOAT,
    ironToSteelTransform FLOAT
);

CREATE TABLE Contract(
    playerID INT constraint FK_Contract_playerID foreign key (playerID) references Player(playerID),
    contractID INT IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
    contractGameID INT,
    title VARCHAR(100),
    description VARCHAR(500),
    steelRequirement INT,
    moneyReward INT,
    timeRemaining FLOAT,
    penalization FLOAT,
    success INT,
    isActive INT
);

CREATE TABLE Trade(
    playerID INT constraint FK_Trade_PlayerID foreign key (playerID) references player(playerID),
    tradeID INT IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
    playerToTradeID INT,
    steelAmount INT,
    steelCost INT,
    acceptTradeP1 INT,
    acceptTradeP2 INT,
    isComplete1 INT,
    isComplete2 INT
);

CREATE TABLE Friend(
    playerID INT constraint FK_Friend_PlayerID foreign key (playerID) references Player(playerID),
    relationID INT IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
    friendID INT,
    Status1 INT,
    Status2 INT,
    UpdateData INT
);

CREATE TABLE Building(
    playerID INT constraint FK_Building_PlayerID foreign key (playerID) references Player(playerID),
    buildingID INT IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
    buildingGameID INT,
    buildingType Varchar(50),
    posX FLOAT,
    posZ FLOAT,
    rotation FLOAT,
    attributeBuildingData VARCHAR(100)
);

CREATE TABLE Usuario(
    IDUsuario INT IDENTITY (1,1) NOT NULL PRIMARY KEY CLUSTERED,
    Nombre VARCHAR(250),
    Apellido VARCHAR(250),
    Email VARCHAR(250),
    Password VARCHAR(250),
    EsAdministrador BIT
);

CREATE TABLE Feedback(
    feedbackID int identity (1,1) NOT NULL PRIMARY KEY CLUSTERED,
    feedbackName VARCHAR(250)
);

CREATE TABLE Player_Feedback(
    playerID INT constraint FK_Player_FeedbackID foreign key (playerID) references Player(playerID),
	feedbackID INT constraint FK_Feedback_PlayerID foreign key (feedbackID) references Feedback(feedbackID),
    activated BIT
);

INSERT INTO [dbo].[Feedback] values ('furnaceFeedback');
INSERT INTO [dbo].[Feedback] values ('energyFeedback');
INSERT INTO [dbo].[Feedback] values ('friendFeedback');