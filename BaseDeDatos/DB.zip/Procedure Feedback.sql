-- Agregar por primera vez la configuracion de los feedbacks  
CREATE PROCEDURE SPAddFeedback @playerID INT, @furnaceFeedback BIT, @energyFeedback BIT, @friendFeedback BIT AS
INSERT INTO [dbo].[Player_Feedback] values (@playerID, 1, @furnaceFeedback);
INSERT INTO [dbo].[Player_Feedback] values (@playerID, 2, @energyFeedback);
INSERT INTO [dbo].[Player_Feedback] values (@playerID, 3, @friendFeedback);

-- Actualizar el valor de los feedbacks
CREATE PROCEDURE SPUpdateFeedback @playerID INT, @furnaceFeedback BIT, @energyFeedback BIT, @friendFeedback BIT AS
UPDATE [dbo].[Player_Feedback] SET activated = @furnaceFeedback WHERE playerID = @playerID AND feedbackID = 1
UPDATE [dbo].[Player_Feedback] SET activated = @energyFeedback WHERE playerID = @playerID AND feedbackID = 2
UPDATE [dbo].[Player_Feedback] SET activated = @friendFeedback WHERE playerID = @playerID AND feedbackID = 3

-- Feedbacks actuales
INSERT INTO [dbo].[Feedback] values ('furnaceFeedback');
INSERT INTO [dbo].[Feedback] values ('energyFeedback');
INSERT INTO [dbo].[Feedback] values ('friendFeedback');

-- Agregar un jugador cualquiera
insert into [dbo].[Player] values (1,'hola',3,4,5,6,7,'True')